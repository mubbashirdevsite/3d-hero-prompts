# 🎨 3D Web Prompts

Ready-to-use AI prompts for building stunning 3D hero sections — Three.js, CSS 3D, Canvas 2D, Spline, and GSAP. Copy a prompt, paste it into Claude or ChatGPT, and ship your 3D hero in minutes.

---

## 📁 Project Structure

```
3D-Web-Prompts/
│
├── index.html              ← Entry point — links all CSS & JS
├── README.md               ← This file
│
├── css/
│   ├── style.css           ← Base styles, layout, components, tokens
│   ├── animations.css      ← All @keyframes and transition classes
│   └── responsive.css      ← Media queries (mobile, tablet, wide)
│
├── js/
│   ├── script.js           ← UI: scroll-reveal, active nav, smooth scroll
│   ├── prompts.js          ← Loads prompts.json → renders cards + copy buttons
│   └── particles.js        ← Canvas 2D hero background particle system
│
├── assets/
│   ├── images/             ← Any static images (OG image, screenshots)
│   ├── icons/              ← SVG icon files if extracted
│   └── backgrounds/        ← Static fallback bg images for no-WebGL browsers
│
└── data/
    └── prompts.json        ← All prompt data (tag, title, desc, prompt text)
```

---

## 🚀 Running Locally

Because `prompts.js` uses `fetch('data/prompts.json')`, you need a local server:

```bash
# Option 1 — Node (npx, no install)
npx serve .

# Option 2 — Python 3
python -m http.server 8080

# Option 3 — VS Code
# Install "Live Server" extension → right-click index.html → Open with Live Server
```

Then open `http://localhost:3000` (or whichever port).

> ⚠️ Opening `index.html` directly via `file://` will cause the `fetch()` call to fail due to CORS restrictions.

---

## ✏️ Adding New Prompts

Edit `data/prompts.json` — add a new object to the array:

```json
{
  "id": 13,
  "tag": "tag-three",
  "tagLabel": "Three.js",
  "title": "Your effect title",
  "desc": "Short one-line description shown on the card.",
  "prompt": "The full prompt text that gets copied to clipboard."
}
```

**Available tag classes:**

| Class        | Color   | Use for      |
|--------------|---------|--------------|
| `tag-three`  | Purple  | Three.js     |
| `tag-css`    | Pink    | CSS 3D       |
| `tag-canvas` | Teal    | Canvas 2D    |
| `tag-spline` | Yellow  | Spline       |
| `tag-gsap`   | Blue    | GSAP         |

No JS changes needed — `prompts.js` reads the JSON automatically.

---

## 🎨 Design Tokens

All colours and typography are controlled via CSS variables in `css/style.css`:

```css
:root {
  --bg:      #050508;   /* Page background      */
  --surface: #0d0d14;   /* Elevated surfaces     */
  --border:  rgba(255,255,255,0.08);
  --accent:  #7c6dfa;   /* Purple — primary CTA  */
  --accent2: #fa6d8a;   /* Pink                  */
  --accent3: #6dfacc;   /* Teal                  */
  --text:    #e8e8f0;   /* Body text             */
  --muted:   #7070a0;   /* Secondary text        */
  --card:    #0f0f1a;   /* Card background       */
}
```

---

## 🧩 JS Architecture

| File           | Responsibility |
|----------------|----------------|
| `script.js`    | IntersectionObserver scroll-reveal, active nav links, nav shadow on scroll |
| `prompts.js`   | `fetch()` → JSON → DOM cards, delegated clipboard copy handler |
| `particles.js` | Canvas 2D particle system — IIFE, mouse repulsion, connection lines, resize |

All three files are **IIFEs** (self-contained) — no globals leak, no framework needed.

---

## ♿ Accessibility

- `prefers-reduced-motion` disables all CSS animations via `animations.css`
- Canvas and orbs carry `aria-hidden="true"`
- Copy buttons use semantic `<button>` elements with visible focus styles

---

## 📱 Responsive Breakpoints

| Breakpoint  | File              | Changes |
|-------------|-------------------|---------|
| ≤ 1024px    | `responsive.css`  | Narrower section padding, 2-col grid |
| ≤ 768px     | `responsive.css`  | Nav links hidden, single-col grid, stacked footer |
| ≤ 480px     | `responsive.css`  | Smaller hero type, tighter card padding |
| ≥ 1440px    | `responsive.css`  | Force 3-col prompt grid |

---

## 🛠 Tech Stack

- **HTML5** — semantic markup
- **CSS3** — custom properties, grid, backdrop-filter, keyframes
- **Vanilla JS** — no frameworks, no build step
- **Google Fonts** — Space Grotesk + Space Mono (loaded via `@import` in `style.css`)

---

*Copy prompts freely — no attribution needed.*
